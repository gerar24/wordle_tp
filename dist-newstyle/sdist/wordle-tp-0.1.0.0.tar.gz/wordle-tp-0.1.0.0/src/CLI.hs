module CLI (main) where

import TinyApp (startApp)

main :: IO()

main = do
    putStrLn "Starting CLI..."
    startApp